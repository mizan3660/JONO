const {onDocumentCreated}=require('firebase-functions/v2/firestore');
const admin=require('firebase-admin'); admin.initializeApp();
exports.onPostCreated=onDocumentCreated('posts/{postId}', async event=>{const p=event.data?.data(); if(!p) return null; return admin.firestore().collection('adminLogs').add({type:'post_created',postId:event.params.postId,authorId:p.authorId,createdAt:admin.firestore.FieldValue.serverTimestamp()});});
